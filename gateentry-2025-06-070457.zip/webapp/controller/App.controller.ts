import Controller from "sap/ui/core/mvc/Controller";

/**
 * @namespace gateentry.controller
 */
export default class App extends Controller {

    /*eslint-disable @typescript-eslint/no-empty-function*/
    public onInit(): void {

    }
}